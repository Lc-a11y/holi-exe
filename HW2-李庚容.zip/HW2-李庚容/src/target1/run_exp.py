"""Target 1: measure SGLang Radix Cache (prefix cache) effect.

Two load groups, each 32 measured requests, max concurrency 8.
  - shared_prefix    : all requests share one long common prefix (pre-warmed)
  - dispersed_prefix : every request has its own unique prefix of the same length

Both groups share model / input length / output length / request order / concurrency.
The only difference is whether the prefix can be reused.

Sampling is fixed: temperature=0, max_new_tokens=16, ignore_eos=true, sampling_seed=2026.
"""

import asyncio
import json
import csv
import random
import time
from pathlib import Path

import httpx
from transformers import AutoTokenizer

BASE_URL = "http://127.0.0.1:30000"
MODEL_PATH = "/mnt/e/WSL/models/Qwen3-0.6B"

NUM_REQ = 32
MAX_CONCURRENT = 8
MAX_NEW_TOKENS = 16
TEMPERATURE = 0.0
SAMPLING_SEED = 2026

PREFIX_LEN = 1024   # tokens in the shared / unique prefix
SUFFIX_LEN = 64     # tokens unique to each request

RESULTS_ROOT = Path("results/target1")

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)


# ---------------------------------------------------------------- load builders

def _token_pool(need: int) -> list[int]:
    """A long, natural token stream used as raw material for prefixes."""
    corpus = (
        "Retrieval augmented generation systems combine a parametric language model "
        "with a non parametric document index so that answers can be grounded in "
        "evidence that was never seen during pretraining. The index is usually built "
        "by splitting documents into passages, encoding each passage with a bi encoder, "
        "and storing the resulting vectors in a nearest neighbour structure. At query "
        "time the same encoder embeds the question and the retriever returns the most "
        "similar passages, which are then concatenated with the question and passed to "
        "the generator. Because the generator attends over every retrieved passage, the "
        "cost of the prefill phase grows with the total number of retrieved tokens, and "
        "the key and value tensors that are produced dominate both latency and memory "
        "footprint for long contexts. Serving stacks therefore cache those tensors and "
        "reuse them whenever a later request begins with exactly the same token sequence "
        "at exactly the same positions. "
    )
    ids: list[int] = []
    while len(ids) < need:
        ids.extend(tokenizer.encode(corpus))
    return ids[:need]


def build_loads() -> dict:
    """Build both load groups with identical token-length structure."""
    rng = random.Random(SAMPLING_SEED)

    # Non-overlapping windows => the dispersed group's prefixes share nothing.
    pool = _token_pool(PREFIX_LEN * (NUM_REQ + 2) + SUFFIX_LEN * NUM_REQ + 8)

    suffixes = []
    off = PREFIX_LEN * (NUM_REQ + 2)
    for i in range(NUM_REQ):
        suffixes.append(pool[off + i * SUFFIX_LEN: off + (i + 1) * SUFFIX_LEN])

    # Shared group: one common prefix, re-used by every request.
    shared_prefix = pool[:PREFIX_LEN]
    shared = [list(shared_prefix) + list(suffixes[i]) for i in range(NUM_REQ)]

    # Dispersed group: every request gets its own disjoint prefix, same total length.
    dispersed = []
    for i in range(NUM_REQ):
        base = PREFIX_LEN * (i + 1)
        dispersed.append(pool[base: base + PREFIX_LEN] + list(suffixes[i]))

    # Warmup request carrying the shared prefix (populates Radix Cache).
    shared_warmup = list(shared_prefix) + tokenizer.encode(" Warm up the cache.")

    rng.random()  # keep rng referenced; layout above is deterministic
    return {
        "shared_prefix": {"warmup": shared_warmup, "reqs": shared},
        "dispersed_prefix": {"warmup": None, "reqs": dispersed},
    }


# ---------------------------------------------------------------- HTTP helpers

async def flush_cache(client: httpx.AsyncClient) -> dict:
    """POST /flush_cache and confirm the server actually cleared the Radix Cache."""
    r = await client.post(f"{BASE_URL}/flush_cache", timeout=60.0)
    # Success -> HTTP 200 with plain text "Cache flushed."; failure -> HTTP 400.
    ok = r.status_code == 200 and "Cache flushed" in r.text
    print(f"[flush_cache] status={r.status_code} confirmed={ok} text={r.text.strip()[:80]}")
    if not ok:
        raise RuntimeError(f"flush_cache not confirmed: {r.status_code} {r.text!r}")
    return {"status_code": r.status_code, "text": r.text.strip()}


async def send_one(client: httpx.AsyncClient, prompt_ids: list[int], req_id: int,
                   sem: asyncio.Semaphore) -> dict:
    payload = {
        "input_ids": prompt_ids,
        "max_new_tokens": MAX_NEW_TOKENS,
        "temperature": TEMPERATURE,
        "ignore_eos": True,
        "sampling_seed": SAMPLING_SEED,
        "stream": True,
    }
    rec = {"req_id": req_id, "prompt_tokens": None, "cached_tokens": None,
           "completion_tokens": None, "ttft": None, "tpot": None, "e2e": None,
           "ok": False, "error": None}

    async with sem:
        t0 = time.perf_counter()
        try:
            async with client.stream("POST", f"{BASE_URL}/generate", json=payload) as r:
                if r.status_code != 200:
                    await r.aread()
                    rec["error"] = f"HTTP {r.status_code}"
                    return rec
                first_ts = None
                last_meta = None
                async for line in r.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    obj = json.loads(data)
                    if "error" in obj:
                        rec["error"] = str(obj["error"])[:200]
                        return rec
                    if first_ts is None:
                        first_ts = time.perf_counter()
                    if "meta_info" in obj:
                        last_meta = obj["meta_info"]
                t_end = time.perf_counter()

            if last_meta is None:
                rec["error"] = "no meta_info in stream"
                return rec

            rec["prompt_tokens"] = last_meta.get("prompt_tokens")
            rec["cached_tokens"] = last_meta.get("cached_tokens")
            rec["completion_tokens"] = last_meta.get("completion_tokens")
            rec["ttft"] = (first_ts - t0) if first_ts else None
            rec["e2e"] = t_end - t0
            ct = rec["completion_tokens"] or 0
            if rec["ttft"] is not None and ct > 1:
                rec["tpot"] = (rec["e2e"] - rec["ttft"]) / (ct - 1)
            rec["ok"] = rec["prompt_tokens"] is not None
        except Exception as e:  # noqa: BLE001
            rec["error"] = f"{type(e).__name__}: {e}"
        return rec


# ---------------------------------------------------------------- statistics

def pct(arr, q):
    if not arr:
        return None
    s = sorted(arr)
    if len(s) == 1:
        return s[0]
    idx = min(len(s) - 1, int(round(q * (len(s) - 1))))
    return s[idx]


async def run_group(name: str, group: dict, warmup_short: list[int] | None,
                    save_dir: Path) -> dict:
    print(f"\n===== group: {name} =====")
    sem = asyncio.Semaphore(MAX_CONCURRENT)
    limits = httpx.Limits(max_connections=MAX_CONCURRENT + 4)

    async with httpx.AsyncClient(timeout=300.0, limits=limits) as client:
        # 1. optional one-off server warmup before the very first measured group
        if warmup_short is not None:
            print("[global warmup] short request")
            await send_one(client, warmup_short, -100, sem)

        # 2. wait for the server to be idle, then flush the Radix Cache
        await asyncio.sleep(1.0)
        await flush_cache(client)
        await asyncio.sleep(1.0)

        # 3. shared-prefix group additionally sends its prefix warmup request
        if group["warmup"] is not None:
            print("[group warmup] seeding shared prefix (not measured)")
            w = await send_one(client, group["warmup"], -1, sem)
            print(f"    warmup cached_tokens={w['cached_tokens']} "
                  f"prompt_tokens={w['prompt_tokens']}")
            await asyncio.sleep(1.0)

        # 4. measured requests: 32 requests, at most 8 in flight
        print(f"submitting {NUM_REQ} measured requests, concurrency {MAX_CONCURRENT}")
        t_group0 = time.perf_counter()
        recs = await asyncio.gather(*[
            send_one(client, group["reqs"][i], i, sem) for i in range(NUM_REQ)
        ])
        wall = time.perf_counter() - t_group0

    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "raw_result.json", "w", encoding="utf-8") as f:
        json.dump(recs, f, indent=2)

    ok = [r for r in recs if r["ok"]]
    tot_prompt = sum(r["prompt_tokens"] for r in ok)
    tot_cached = sum(r["cached_tokens"] for r in ok)
    tot_out = sum(r["completion_tokens"] for r in ok)
    ttft = [r["ttft"] for r in ok if r["ttft"] is not None]
    tpot = [r["tpot"] for r in ok if r["tpot"] is not None]
    e2e = [r["e2e"] for r in ok if r["e2e"] is not None]

    summary = {
        "group": name,
        "success_cnt": len(ok),
        "success_rate": len(ok) / NUM_REQ,
        "concurrency": MAX_CONCURRENT,
        "wall_time_s": wall,
        "prompt_len": ok[0]["prompt_tokens"] if ok else None,
        "completion_tokens_total": tot_out,
        "total_prompt_tokens": tot_prompt,
        "total_cached_tokens": tot_cached,
        "cache_hit_rate": (tot_cached / tot_prompt) if tot_prompt else 0.0,
        "actual_prefill_tokens": tot_prompt - tot_cached,
        "throughput_tokens_per_sec": (tot_out / wall) if wall else 0.0,
        "ttft_p50": pct(ttft, 0.50), "ttft_p95": pct(ttft, 0.95),
        "tpot_p50": pct(tpot, 0.50), "tpot_p95": pct(tpot, 0.95),
        "e2e_p50": pct(e2e, 0.50), "e2e_p95": pct(e2e, 0.95),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    with open(save_dir / "summary.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summary.keys()))
        w.writeheader()
        w.writerow(summary)
    return summary


async def main():
    loads = build_loads()
    short_warmup = tokenizer.encode("short warmup request")

    summaries = []
    summaries.append(await run_group(
        "shared_prefix", loads["shared_prefix"], short_warmup,
        RESULTS_ROOT / "shared_prefix" / "run-1"))
    summaries.append(await run_group(
        "dispersed_prefix", loads["dispersed_prefix"], None,
        RESULTS_ROOT / "dispersed_prefix" / "run-1"))

    print("\n===== comparison =====")
    for s in summaries:
        print(f"{s['group']:18s} hit={s['cache_hit_rate']:.4f} "
              f"prefill={s['actual_prefill_tokens']} "
              f"ttft_p50={s['ttft_p50']:.4f} tpot_p50={s['tpot_p50']:.6f}")


if __name__ == "__main__":
    asyncio.run(main())
