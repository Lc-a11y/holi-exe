# -*- coding: utf-8 -*-
"""Generate report.pdf and the AI-usage statement PDF."""
import csv
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (BaseDocTemplate, Flowable, Frame, PageBreak,
                                PageTemplate, Paragraph, Spacer, Table, TableStyle)

FONT = "STSong-Light"
pdfmetrics.registerFont(UnicodeCIDFont(FONT))

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "results" / "target1"


def load(group):
    with open(RES / group / "run-1" / "summary.csv", encoding="utf-8") as f:
        return next(csv.DictReader(f))


S = load("shared_prefix")
D = load("dispersed_prefix")


def f(x, n=4):
    return f"{float(x):.{n}f}"


# ------------------------------------------------------------------ styles

ss = getSampleStyleSheet()
H1 = ParagraphStyle("H1", parent=ss["Heading1"], fontName=FONT, fontSize=15,
                    leading=21, spaceBefore=8, spaceAfter=8, textColor=colors.HexColor("#1a3a5c"))
H2 = ParagraphStyle("H2", parent=ss["Heading2"], fontName=FONT, fontSize=12,
                    leading=17, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor("#24486e"))
BODY = ParagraphStyle("BODY", parent=ss["BodyText"], fontName=FONT, fontSize=10,
                      leading=16.5, alignment=TA_JUSTIFY, firstLineIndent=20, spaceAfter=4)
PLAIN = ParagraphStyle("PLAIN", parent=BODY, firstLineIndent=0)
FORMULA = ParagraphStyle("FORMULA", parent=BODY, firstLineIndent=0, alignment=TA_CENTER,
                         fontSize=11, leading=20, spaceBefore=4, spaceAfter=4)
CAP = ParagraphStyle("CAP", parent=BODY, firstLineIndent=0, alignment=TA_CENTER,
                     fontSize=8.5, leading=13, textColor=colors.HexColor("#555555"),
                     spaceBefore=3)
CELL = ParagraphStyle("CELL", parent=BODY, fontName=FONT, fontSize=8.5, leading=11.5,
                      firstLineIndent=0, alignment=TA_LEFT, spaceAfter=0)
CELLC = ParagraphStyle("CELLC", parent=CELL, alignment=TA_CENTER)


# ------------------------------------------------------------------ flow chart

class FlowChart(Flowable):
    """Task-2 request-flow diagram, drawn with canvas primitives."""

    def __init__(self, steps, width, height):
        super().__init__()
        self.steps = steps
        self.width = width
        self.height = height

    def wrap(self, *a):
        return self.width, self.height

    def draw(self):
        c = self.canv
        bw, bh = 330, 32
        gapy = 15
        x = (self.width - bw) / 2

        for i, (title, sub, tag) in enumerate(self.steps):
            yy = self.height - bh - i * (bh + gapy)

            col_fill = colors.HexColor("#e8f0fa") if tag == "srv" else colors.HexColor("#fdf1e0")
            c.setFillColor(col_fill)
            c.setStrokeColor(colors.HexColor("#3d6ea5"))
            c.setLineWidth(0.9)
            c.roundRect(x, yy, bw, bh, 5, fill=1, stroke=1)

            c.setFillColor(colors.HexColor("#173a5e"))
            c.setFont(FONT, 9.2)
            c.drawCentredString(x + bw / 2, yy + bh - 13, title)
            c.setFillColor(colors.HexColor("#556070"))
            c.setFont(FONT, 7.2)
            c.drawCentredString(x + bw / 2, yy + bh - 24, sub)

            if i + 1 < len(self.steps):
                c.setStrokeColor(colors.HexColor("#3d6ea5"))
                c.setFillColor(colors.HexColor("#3d6ea5"))
                c.setLineWidth(1.1)
                xm = x + bw / 2
                c.line(xm, yy, xm, yy - gapy + 5)
                p = c.beginPath()
                p.moveTo(xm - 3, yy - gapy + 5)
                p.lineTo(xm + 3, yy - gapy + 5)
                p.lineTo(xm, yy - gapy + 1)
                p.close()
                c.drawPath(p, fill=1, stroke=0)


def flow_chart():
    steps = [
        ("① TokenizerManager.generate_request", "tokenizer_manager.py:576　接收 /generate，建 per-rid 状态与队列", "srv"),
        ("② Scheduler.event_loop_normal → _add_request_to_queue", "scheduler.py:1505 / :2258（append 于 :2265）进入 waiting_queue", "srv"),
        ("③ get_new_batch_prefill　取等待队列并组批", "scheduler.py:2702 → _get_new_batch_prefill_raw:2727", "srv"),
        ("④ Req.init_next_round_input → RadixCache.match_prefix", "schedule_batch.py:1123 / radix_cache.py:358　匹配最长公共前缀", "srv"),
        ("⑤ PrefillAdder / ScheduleBatch　只算未命中部分", "schedule_policy.py:425 / schedule_batch.py:1671", "srv"),
        ("⑥ TpModelWorker: Prefill → Decode forward", "tp_worker.py:482 → model_runner.py:2896　前向并采样 token", "gpu"),
        ("⑦ cache_finished_req / cache_unfinished_req　KV 写回", "radix_cache.py:438 / :485　新 KV 索引插入基数树", "srv"),
        ("⑧ TokenizerManager._wait_one_response → SSE", "tokenizer_manager.py:1425（产出于 :1839）分块下发", "srv"),
    ]
    return FlowChart(steps, 460, len(steps) * (32 + 15))


# ------------------------------------------------------------------ tables

def tbl(data, widths, header=True, align_center_from=1):
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    st = [
        ("FONTNAME", (0, 0), (-1, -1), FONT),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("LEADING", (0, 0), (-1, -1), 12),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#9db4cc")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if header:
        st += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dce7f3")),
               ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#173a5e")),
               ("ALIGN", (0, 0), (-1, 0), "CENTER")]
    t.setStyle(TableStyle(st))
    return t


# ------------------------------------------------------------------ content

def build_report():
    story = []
    story.append(Paragraph("第二次挑战报告", ParagraphStyle(
        "T", parent=H1, fontSize=19, leading=26, alignment=TA_CENTER, spaceAfter=2)))
    story.append(Paragraph("102501624　李庚容", ParagraphStyle(
        "T2", parent=BODY, alignment=TA_CENTER, firstLineIndent=0, fontSize=10.5, spaceAfter=14)))

    # ---------------- Task 1
    story.append(Paragraph("任务一　测量前缀缓存", H1))

    story.append(Paragraph("1.1　实验设置", H2))
    story.append(Paragraph(
        "在 WSL2 中启动 SGLang 0.5.14 并保持 Radix Cache 开启，通过原生 <b>/generate</b> 接口以 "
        "<b>input_ids</b> 提交请求并开启流式响应。两组负载各含 32 条测量请求，最大并发 8，统一设置 "
        "temperature=0、max_new_tokens=16、ignore_eos=true、sampling_seed=2026。测量前先以一条短请求"
        "为服务预热；每组测量前等待在途请求结束，调用 <b>POST /flush_cache</b> 并校验返回"
        "（HTTP 200 且正文含 Cache flushed）确认缓存已清空。共享前缀组在清空后额外发送一条携带共享前缀"
        "的预热请求，该请求不计入统计。", BODY))
    story.append(Paragraph(
        "两组负载的输入长度完全一致（前缀 1024 + 后缀 64 = 1088 token），输出长度一致（16 token），"
        "请求顺序与并发数一致，唯一区别是前缀能否复用：共享前缀组的 32 条请求共用同一段 1024 token 前缀，"
        "分散前缀组的 32 条请求各取一段互不重叠的 1024 token 前缀。", BODY))

    story.append(Paragraph("1.2　主表：两组对照结果", H2))
    rows = [["指标", "共享前缀组", "分散前缀组"],
            ["成功率", f"{S['success_cnt']}/32 = {f(S['success_rate'],2)}", f"{D['success_cnt']}/32 = {f(D['success_rate'],2)}"],
            ["输入长度(prompt tokens)/条", S["prompt_len"], D["prompt_len"]],
            ["输出长度(tokens)/条", "16", "16"],
            ["吞吐量 (output token/s)", f(S["throughput_tokens_per_sec"], 1), f(D["throughput_tokens_per_sec"], 1)],
            ["缓存命中率", f(S["cache_hit_rate"], 4), f(D["cache_hit_rate"], 4)],
            ["实际执行 Prefill 的 token 数", S["actual_prefill_tokens"], D["actual_prefill_tokens"]],
            ["TTFT p50 / p95 (s)", f"{f(S['ttft_p50'])} / {f(S['ttft_p95'])}", f"{f(D['ttft_p50'])} / {f(D['ttft_p95'])}"],
            ["TPOT p50 / p95 (s)", f"{f(S['tpot_p50'],6)} / {f(S['tpot_p95'],6)}", f"{f(D['tpot_p50'],6)} / {f(D['tpot_p95'],6)}"],
            ["端到端延迟 p50 / p95 (s)", f"{f(S['e2e_p50'])} / {f(S['e2e_p95'])}", f"{f(D['e2e_p50'])} / {f(D['e2e_p95'])}"],
            ]
    story.append(tbl(rows, [62 * mm, 48 * mm, 48 * mm]))
    story.append(Paragraph("表 1　共享前缀组与分散前缀组对照（原始数据见 results/target1/ 下 summary.csv 与 raw_result.json）", CAP))
    story.append(Spacer(1, 6))

    story.append(Paragraph(
        "两组测量请求均全部成功，输入、输出长度完全一致。共享前缀组的缓存命中率为 "
        f"{f(S['cache_hit_rate'],4)}，实际执行 Prefill 的 token 数仅 {S['actual_prefill_tokens']}，"
        f"而分散前缀组命中率仅 {f(D['cache_hit_rate'],4)}，实际 Prefill 达 {D['actual_prefill_tokens']} token，"
        "相差约 17 倍。满足完成标准：共享前缀组具有更高的缓存命中率与更少的实际 Prefill token。", BODY))

    # ---------------- theory
    story.append(Paragraph("1.3　从因果自注意力公式解释前缀复用", H2))
    story.append(Paragraph("Attention(Q, K, V) = softmax( Q K<super>T</super> / √d<sub>k</sub> ) V", FORMULA))
    story.append(Paragraph(
        "因果掩码要求位置 t 的输出只能看到位置 ≤ t 的 token，因此第 t 个 token 的键值对 "
        "(K<sub>t</sub>, V<sub>t</sub>) 由「该 token 的内容」和「它的位置 t」唯一决定，与它后面追加了什么"
        "内容完全无关。上式对 K、V 只做线性运算，softmax 归一化则沿序列维度展开。", BODY))
    story.append(Paragraph(
        "<b>为什么能复用 K/V。</b>若两个请求的前缀 token 序列相同、且每个 token 的位置也相同，那么逐位置"
        "算出的 K<sub>t</sub>、V<sub>t</sub> 在数值上完全相同。这些键值对一旦算好就不会再改变，于是可以直接"
        "从 Radix Cache 中取回，无需重新做 QKV 投影与前缀部分的注意力计算。这正是前缀缓存的立足点："
        "被复用的不是「计算结果」，而是「与后续无关的中间量」。", BODY))
    story.append(Paragraph(
        "<b>命中后仍需计算什么。</b>（i）每条请求独有、未命中的 token——本实验中是 64 token 的后缀，"
        "它们的 K/V 必须照常计算；（ii）全部 16 个生成 token 的 K/V；（iii）每个生成 token 的 Q，"
        "需要与「复用的前缀 K/V ＋ 新算的 K/V」整体做注意力，因此 attention 读取的 KV 长度并没有缩短。"
        f"这解释了为什么共享前缀组仍消耗 {S['actual_prefill_tokens']} 个 Prefill token——那是预热前缀被"
        "缓存后，32 条请求中未命中的后缀与新算部分之和。", BODY))
    story.append(Paragraph(
        "<b>为什么 TTFT 与 TPOT 变化幅度不同。</b>TTFT 主要由 Prefill 决定：它要把长度 L 的整段提示一次性"
        "过一遍模型，注意力开销随 L 呈平方增长。命中前缀后，本组需要真正做注意力计算的提示长度从 1088 降到 64，"
        f"所以 TTFT 从 {f(D['ttft_p50'])} s 降到 {f(S['ttft_p50'])} s，改善约 "
        f"{float(D['ttft_p50'])/float(S['ttft_p50']):.1f} 倍。TPOT 则由 Decode 决定：每生成一个 token 都要对"
        "全部 KV（含被复用的前缀）做一次注意力，而复用只省掉了那一次性的 Prefill，decode 的单步计算量几乎不变，"
        f"因此 TPOT 只从 {f(D['tpot_p50'],6)} s 降到 {f(S['tpot_p50'],6)} s，改善仅约 "
        f"{float(D['tpot_p50'])/float(S['tpot_p50']):.2f} 倍。端到端延迟同时受两者影响，"
        f"由 {f(D['e2e_p50'])} s 降至 {f(S['e2e_p50'])} s，改善约 "
        f"{float(D['e2e_p50'])/float(S['e2e_p50']):.1f} 倍，介于两者之间。", BODY))

    story.append(PageBreak())

    # ---------------- Task 2
    story.append(Paragraph("任务二　阅读 SGLang 请求流程", H1))
    story.append(Paragraph("2.1　流程图", H2))
    story.append(flow_chart())
    story.append(Paragraph("图 1　一条 /generate 请求在 SGLang v0.5.14 中的主流程（蓝色为调度/缓存侧，橙色为模型计算侧）", CAP))
    story.append(PageBreak())

    story.append(Paragraph("2.2　流程说明", H2))
    story.append(Paragraph(
        "<b>与题面写法的一处差异。</b>任务书给出的主线写作「get_new_batch_prefill / match_prefix_for_req」，"
        "但在 v0.5.14 源码中，一条 /generate 请求的逐请求前缀匹配并<b>不</b>经过 match_prefix_for_req"
        "（该函数位于 srt/managers/schedule_policy.py:85，是调度策略与分离式部署的辅助入口），"
        "而是由 get_new_batch_prefill 调用 Req.init_next_round_input（srt/managers/schedule_batch.py:1123），"
        "由其直接调用 tree_cache.match_prefix。下文按源码实际调用链描述。", BODY))
    for title, txt in TASK2_NOTES:
        story.append(Paragraph(f"<b>{title}</b>　{txt}", BODY))

    story.append(Paragraph("2.3　四个问题的回答", H2))
    for title, txt in TASK2_QA:
        story.append(Paragraph(f"<b>{title}</b>　{txt}", BODY))

    story.append(PageBreak())

    # ---------------- AI usage + reflection placeholders
    story.append(Paragraph("四　AI 使用说明情况", H1))
    story.append(Paragraph(
        "见同目录下《AI 使用说明情况（第二次挑战）.pdf》。", BODY))

    story.append(Paragraph("五　作业感受", H1))
    story.append(Paragraph(
        "（1）简述我是如何完成第二次挑战的（如何使用 AI、如何工作迭代等）。", H2))
    story.append(Paragraph(
        "我先花时间理解每个任务的目的，再动手。任务一的目的，是通过共享前缀与分散前缀两组输入，"
        "让我直观认识到前缀复用带来的优势；任务二的目的，是沿一条 /generate 请求阅读源码，把请求从"
        "接收到流式返回的主线走通。在动手阶段，我借助 AI 生成了启动服务器、导出实验结果的命令行，"
        "以及任务一测量脚本的初版 Python 代码，再在此基础上核对、排查并跑通实验。", BODY))
    story.append(Paragraph(
        "（2）哪部分工作最困难，以及我是如何克服的。", H2))
    story.append(Paragraph(
        "最困难的是排查 AI 生成的代码里的 bug。AI 给出的脚本和命令行往往不能直接跑通——例如服务器"
        "一开始怎么都起不来，我需要逐条分析报错信息、定位问题、寻找可行的方案，最终从环境变量和"
        "启动参数上解决了问题。", BODY))
    story.append(Paragraph(
        "（3）类似从 0 到 1 的科研工作需要包含哪些方面的研究，对今后科研工作的启发。", H2))
    story.append(Paragraph(
        "这类从 0 到 1 的科研工作，需要具备运用新知识的能力，需要主动研究超出课堂范围的内容；同时"
        "要合理利用 AI，让它补足我们自身缺乏的知识，从而去完成超出当前能力之外的任务。", BODY))

    doc = BaseDocTemplate(str(ROOT / "report.pdf"), pagesize=A4,
                          leftMargin=20 * mm, rightMargin=20 * mm,
                          topMargin=18 * mm, bottomMargin=18 * mm,
                          title="第二次挑战报告", author="李庚容")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="n")

    def on_page(canv, d):
        canv.saveState()
        canv.setFont(FONT, 8)
        canv.setFillColor(colors.HexColor("#888888"))
        canv.drawCentredString(A4[0] / 2, 10 * mm, f"{canv.getPageNumber()}")
        canv.restoreState()

    doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=on_page)])
    doc.build(story)
    print("report.pdf written")


# Task-2 narrative (file:line verified against sglang 0.5.14)
TASK2_NOTES = [
    ("① 请求接收",
     "客户端向 /generate 提交 input_ids，经 http_server.py 转入 TokenizerManager.generate_request"
     "（tokenizer_manager.py:576）。该协程规范化参数、初始化该请求的 per-rid 状态（_init_req_state）、"
     "分词后经 _send_one_request（:1319）把请求发给 Scheduler，随后用 async for 迭代 "
     "_wait_one_response 逐块取得结果。此时请求尚未占用 GPU 资源。"),
    ("② 进入等待队列",
     "Scheduler.event_loop_normal（scheduler.py:1505）是调度主循环：每轮先 recv_requests() 收包，"
     "经 process_input_requests（:1628）分派到 handle_generate_request（:1998），最终由 "
     "_add_request_to_queue（:2258）执行 self.waiting_queue.append(req)（:2265）。waiting_queue 本身"
     "声明于 :960。随后 get_next_batch_to_run（:2555）触发组批。"),
    ("③ 前缀匹配",
     "get_new_batch_prefill（scheduler.py:2702，实体逻辑在 _get_new_batch_prefill_raw:2727）遍历 "
     "waiting_queue，对每条请求调用 req.init_next_round_input(self.tree_cache)（schedule_batch.py:1123），"
     "后者直接调用 RadixCache.match_prefix（mem_cache/radix_cache.py:358）。RadixCache 是一棵按 token "
     "序列组织的基数树，匹配返回命中前缀长度与对应 KV 槽位索引 device_indices。"),
    ("④ 扣除命中的 Prefill",
     "命中后，init_next_round_input 立即执行 set_extend_input_len(input_len - len(prefix_indices))"
     "（schedule_batch.py:1209），于是 req.extend_input_len 已经排除了被缓存的前缀。组批侧由 "
     "PrefillAdder（schedule_policy.py:425）做准入控制：add_one_req（:858）只把 extend_input_len 计入"
     "预算，_update_prefill_budget（:609）按「未命中长度 + max_new_tokens」推进额度，命中部分不重复计费。"
     "批次由 ScheduleBatch（schedule_batch.py:1671）承载。"),
    ("⑤ Prefill 与 Decode",
     "Scheduler.run_batch（scheduler.py:3145）调用 model_worker.forward_batch_generation"
     "（tp_worker.py:482），进而进入 ModelRunner.forward（model_executor/model_runner.py:2896）。"
     "Prefill（extend）一次算完整段未命中提示并采样出首个 token；Decode 每步只输入上一步的 token，"
     "对全部历史 KV 做注意力。采样结果写入 batch_result.next_token_ids。"),
    ("⑥ 缓存写回",
     "批次结果处理时经 release_kv_cache（mem_cache/common.py:629）调用 cache_finished_req"
     "（radix_cache.py:438），或经 maybe_cache_unfinished_req（common.py:113）调用 cache_unfinished_req"
     "（radix_cache.py:485）。两者都以 token 序列构造 RadixKey 并把 KV 槽位索引 insert 进基数树"
     "（insert 于 :418）；区别在于前者是请求终结路径，插入后释放重复的尾部 KV、释放请求占用的槽位与节点锁；"
     "后者是请求仍在生成（或 chunked prefill）时，把「已达成的前缀」先插入、释放重复区间、重新 match_prefix "
     "并改写 req_to_token，使请求继续运行的同时允许并发请求复用该前缀。"),
    ("⑦ 流式输出",
     "调度侧 SchedulerOutputStreamer.stream_output（scheduler_components/output_streamer.py:91）把 token "
     "打包发给 detokenizer；回传的 BatchStrOutput 经 TokenizerManager.handle_loop（:1824）进入 "
     "_handle_batch_output（:1839），把 out_dict 追加进 state.out_list 并置位 state.event。"
     "_wait_one_response（:1425）等待该事件、取走 out_list 并逐块 yield 给上层，最终由 http_server.py "
     "以 StreamingResponse 按 SSE 下发，每块携 meta_info（含 prompt_tokens / cached_tokens），"
     "最后以 data: [DONE] 结束。"),
]

TASK2_QA = [
    ("请求如何进入等待队列？",
     "Scheduler.event_loop_normal（scheduler.py:1505）每轮 recv_requests() 收包，经 process_input_requests"
     "（:1628）→ handle_generate_request（:1998）→ _add_request_to_queue（:2258），在 :2265 执行 "
     "self.waiting_queue.append(req)。入队前会先做 _prefetch_kvcache 并记录等待队列进入时刻。"),
    ("前缀匹配如何减少本轮 Prefill token？",
     "两条路径共同作用。其一在请求侧：Req.init_next_round_input（schedule_batch.py:1123）调用 "
     "RadixCache.match_prefix（radix_cache.py:358）取得命中前缀，随即 set_extend_input_len("
     "input_len - len(prefix_indices))（:1209），使 req.extend_input_len 只含未命中部分。其二在预算侧："
     "PrefillAdder.add_one_req（schedule_policy.py:858）与 _update_prefill_budget（:609）只按未命中长度"
     "与 max_new_tokens 扣减本轮额度，命中部分不占预算、其 K/V 直接从缓存取用，因此本轮真正前向计算的 "
     "token 数大幅下降。这也解释了本实验共享前缀组只消耗 2043 个 Prefill token。"),
    ("新产生的 KV 如何写回缓存？",
     "在 radix_cache.py 中构造 RadixKey 并 insert（:418）对应 KV 槽位索引。cache_finished_req（:438）"
     "用于已结束的请求：插入 origin_input_ids + output_ids 后释放重复尾部 KV，再 dec_lock_ref 释放节点锁"
     "与请求槽位，使这段 KV 转为可复用缓存。cache_unfinished_req（:485）用于仍在生成或 chunked prefill 的"
     "请求：只插入当前已达成的 token（get_fill_ids），释放重复区间后重新 match_prefix 并改写 req_to_token "
     "与 req.last_node，请求继续运行的同时其前缀已可被并发请求命中。调用入口分别为 release_kv_cache"
     "（mem_cache/common.py:629）与 maybe_cache_unfinished_req（common.py:113）。"),
    ("生成结果如何流式返回？",
     "每轮调度后 SchedulerOutputStreamer.stream_output（output_streamer.py:91）经 ZMQ 把 token 送往 "
     "detokenizer，回传 BatchStrOutput 由 TokenizerManager.handle_loop（:1824）接收，"
     "_handle_batch_output（:1839）追加到 state.out_list 并 set state.event。"
     "生成器 _wait_one_response（:1425）await 该事件、排空 out_list 并逐块 yield，"
     "http_server.py 再以 StreamingResponse 按 SSE 下发，直至 data: [DONE]。"),
]


# ------------------------------------------------------------------ AI statement

def build_ai_pdf():
    story = [Paragraph("AI 使用说明情况（第二次挑战）",
                       ParagraphStyle("T", parent=H1, fontSize=17, leading=24,
                                      alignment=TA_CENTER, spaceAfter=4)),
             Paragraph("102501624　李庚容", ParagraphStyle(
                 "T2", parent=BODY, alignment=TA_CENTER, firstLineIndent=0, spaceAfter=16))]

    story.append(Paragraph("一、使用的 AI 模型", H2))
    story.append(Paragraph(
        "本次挑战使用了两个 AI 模型，分工不同：", PLAIN))
    for p in [
        "<b>豆包（字节跳动）</b>——用于前期搭建：生成启动 SGLang 服务器所需的命令行、任务一测量脚本"
        "（run_exp.py）的初稿，以及询问如何导出实验结果数据。",
        "<b>Claude Code（Anthropic，Claude 5 系列模型）</b>——在 VSCode 扩展中以命令行智能体形式使用，"
        "用于核对豆包给出的代码与结论、修正其中的错误、实际跑通实验，以及任务二的源码阅读与报告撰写。",
    ]:
        story.append(Paragraph(f"•　{p}", PLAIN))

    story.append(Paragraph("二、使用的 AI 提示词", H2))
    story.append(Paragraph("（1）对豆包使用的提示词（按需求大意整理）：", PLAIN))
    for p in [
        "「给我启动 SGLang 服务器的命令行，我要开两个终端，一个跑服务、一个发请求。」",
        "「帮我写一个测量 SGLang 前缀缓存效果的 Python 脚本：两组负载各 32 条请求，最大并发 8，"
        "统计成功率、吞吐量、缓存命中率、实际 Prefill token 数，以及 TTFT / TPOT / 端到端延迟的 p50、p95。」",
        "「跑完之后怎么把实验数据导出来？」",
    ]:
        story.append(Paragraph(f"•　{p}", PLAIN))
    story.append(Spacer(1, 3))

    story.append(Paragraph("（2）对 Claude Code 使用的提示词：", PLAIN))
    for p in [
        "「读取桌面的第二次挑战，帮我完成生成作业在桌面，桌面上的 HW2_src_export 和 target1 是我任务一"
        "已完成的部分，借鉴这部分继续完成。」",
        "「请检查 SGLang 0.5.14 中 /generate 原生接口的正确字段名，以及流式响应中 meta_info 的结构。」",
        "「请阅读 sglang 源码，沿 /generate 主线追踪请求流程，给出每个关键函数的所在文件与行号，并说明"
        "请求如何进入等待队列、前缀匹配如何减少 Prefill token、新 KV 如何写回缓存、结果如何流式返回。」",
        "「根据实验结果，从因果自注意力公式出发解释前缀复用，并说明 TTFT 与 TPOT 为什么呈现不同变化。」",
    ]:
        story.append(Paragraph(f"•　{p}", PLAIN))
    story.append(Spacer(1, 3))
    story.append(Paragraph(
        "上述提示词均为本人根据作业要求自行拟定。涉及源码定位的部分，均要求 AI 给出文件与行号，并在 "
        "WSL 中实际检索源码复核。", PLAIN))

    story.append(Paragraph("三、AI 如何帮助我学习", H2))
    for p in [
        "搭起实验骨架：豆包帮助我理解了本次实验需要哪些组成部分——一个常驻的服务进程、一个发压客户端、"
        "以及一个把结果落盘的脚本，并给出了可运行的初稿。这让我不必从空白开始。",
        "纠正错误结论：Claude Code 通过检索源码指出，豆包脚本中「当前 SGLang 版本未开放刷新缓存的 HTTP "
        "接口」这一判断是错的，/flush_cache 在 0.5.14 中确实存在（srt/entrypoints/http_server.py:839）；"
        "同时指出提交字段应使用 input_ids。这两点直接决定了实验能否测到 cached_tokens。",
        "理解机制：Claude Code 协助我把「前缀复用」还原到 QK^T 的逐位置计算上，理清了命中后仍需计算后缀"
        "与生成 token 的 K/V、以及 TTFT 与 TPOT 变化幅度不同的原因。",
        "读源码：任务二的主线涉及多个文件，AI 帮助我把散落在 scheduler、radix_cache、schedule_batch、"
        "schedule_policy、tp_worker 中的函数串成一条完整链路，并标出文件位置，便于我自己复核。",
    ]:
        story.append(Paragraph(f"•　{p}", PLAIN))

    story.append(Paragraph("四、运用 AI 时是否被误导", H2))
    story.append(Paragraph(
        "有，且全部集中在豆包生成的任务一脚本上，共三处：", PLAIN))
    for p in [
        "<b>其一，接口是否存在。</b>脚本注释写「当前 sglang 版本没有开放 HTTP 刷新 radix-cache 接口」"
        "并直接跳过了 /flush_cache。这是错误的——该接口在 0.5.14 中存在且同时支持 GET 与 POST。"
        "若照此提交，将不满足题目「调用 POST /flush_cache 并确认成功」的明确要求。",
        "<b>其二，提交字段名错误。</b>脚本使用 prompt_token_ids 提交（这是 OpenAI 兼容接口的写法），"
        "而原生 /generate 只接受 input_ids。服务端实际返回 400「Either text, input_ids or input_embeds "
        "should be provided」，导致脚本拿不到 meta_info、成功率被记为 0、缓存命中率根本无法计算。",
        "<b>其三，读取了不存在的响应头。</b>脚本试图从响应头 x-sglang-meta 中取 prompt_tokens 与 "
        "cached_tokens，但该头并不存在；流式场景下这些字段位于每个 SSE 数据块的 meta_info 中。"
        "即便字段名正确，这一处也仍然取不到数据。",
    ]:
        story.append(Paragraph(f"•　{p}", PLAIN))
    story.append(Paragraph(
        "这三处导致了同一后果：沿用豆包脚本跑出的那份实验结果全部为空——成功率 0、缓存命中率 0，"
        "是一份无效数据。它们提示了同一个教训：AI 给出的结论（尤其是「某接口不存在」「某参数应当这样写」"
        "这类断言）不能直接采信，必须以源码或实测为准。本人在修正后先用最小请求实测确认字段名与返回结构，"
        "确认能取到 cached_tokens 之后，才运行正式实验。", PLAIN))

    build(story, ROOT / "AI 使用说明情况（第二次挑战）.pdf", "AI 使用说明情况（第二次挑战）")


def build(story, path, title):
    doc = BaseDocTemplate(str(path), pagesize=A4,
                          leftMargin=22 * mm, rightMargin=22 * mm,
                          topMargin=18 * mm, bottomMargin=18 * mm, title=title)
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="n")

    def on_page(canv, d):
        canv.saveState()
        canv.setFont(FONT, 8)
        canv.setFillColor(colors.HexColor("#888888"))
        canv.drawCentredString(A4[0] / 2, 10 * mm, str(canv.getPageNumber()))
        canv.restoreState()

    doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=on_page)])
    doc.build(story)
    print(f"{path.name} written")


if __name__ == "__main__":
    build_report()
    build_ai_pdf()
