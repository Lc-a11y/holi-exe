# HW2 — SGLang 前缀缓存测量与请求流程阅读

第二次挑战作业。本仓库包含两个任务的代码、原始结果与报告。

- 学号 / 姓名：102501624 / 李庚容
- 任务一：测量 SGLang Radix Cache（前缀缓存）的效果
- 任务二：阅读 SGLang v0.5.14 源码，追踪一条 `/generate` 请求的主流程

---

## 1. 环境

| 项目 | 版本 / 说明 |
|---|---|
| GPU | NVIDIA GeForce RTX 5060 Laptop GPU，8 GB 显存 |
| 驱动 / CUDA | 617.14 / CUDA UMD 13.4 |
| 操作系统 | Windows 11 + WSL2 Ubuntu 22.04 |
| Python | 3.11（conda 环境 `sglang_hw2`） |
| SGLang | 0.5.14 |
| Ray | 2.56.0 |
| PyTorch | 2.11.0+cu130（CUDA 可用） |
| 模型 | `Qwen/Qwen3-0.6B`（本地路径 `/mnt/e/WSL/models/Qwen3-0.6B`） |

> 全部实验在 WSL2 中完成，Windows 侧仅用于编辑与生成报告。

### 安装方法

```bash
conda create -n sglang_hw2 python=3.11 -y
conda activate sglang_hw2
pip install sglang==0.5.14 ray==2.56.0 torch transformers accelerate httpx
```

---

## 2. 启动服务

```bash
export FLASHINFER_JIT_DISABLE=1
export FLASHINFER_CACHE_DIR=/tmp/flashinfer_cache

python -m sglang.launch_server \
  --model-path /mnt/e/WSL/models/Qwen3-0.6B \
  --host 127.0.0.1 --port 30000 \
  --radix-cache true \
  --enable-cache-report \
  --max-total-tokens 16384
```

说明：

- `--radix-cache true`：保持 Radix Cache（前缀缓存）开启，这是本实验的自变量来源。
- `--enable-cache-report`：让服务端在 `meta_info` 中回报 `cached_tokens`，用于计算缓存命中率与实际
  Prefill token 数。
- `FLASHINFER_JIT_DISABLE=1`：本机 RTX 5060（sm_120）上 FlashInfer 的 JIT 编译会因 CUDA 头文件
  版本不一致而失败，关闭 JIT 后直接使用预编译 kernel。
- 就绪检查：`curl http://127.0.0.1:30000/health`，返回 200 即表示可接收请求。

---

## 3. 回放实验

```bash
python src/target1/run_exp.py
```

脚本会自动依次完成：

1. 发送一条**短请求**为服务预热（仅在第一个测量组之前执行一次）；
2. 等待在途请求结束，`POST /flush_cache` 并**校验**返回内容（HTTP 200 且正文含 `Cache flushed`）；
3. `shared_prefix` 组额外发送**前缀预热请求**（不计入统计），使共享前缀进入 Radix Cache；
4. 以最大并发 8 提交 **32 条**测量请求，逐条记录 TTFT / TPOT / E2E 与 `meta_info` 中的
   `prompt_tokens`、`cached_tokens`；
5. 对第二组重复步骤 2–4（`dispersed_prefix` 组无前缀预热）；
6. 写出 `raw_result.json`（逐请求）与 `summary.csv`（汇总）。

所有请求统一使用 `temperature=0`、`max_new_tokens=16`、`ignore_eos=true`、`sampling_seed=2026`，
经原生 `/generate` 接口以 `input_ids` 提交并开启 `stream=true`。

### 两组负载的构造

两组**输入长度完全相同**（前缀 1024 + 后缀 64 = 1088 token），**输出长度相同**（16 token），
**请求顺序与并发数相同**，唯一区别是前缀能否复用：

- `shared_prefix`：32 条请求共享同一段 1024 token 前缀，仅后缀不同；测量前用一条携带该前缀的预热
  请求把前缀写入 Radix Cache。
- `dispersed_prefix`：32 条请求各自取一段**互不重叠**的 1024 token 前缀（保证彼此不共享任何前缀），
  后缀与共享组逐条一致。

---

## 4. 脚本用途

| 文件 | 用途 |
|---|---|
| `src/target1/run_exp.py` | 任务一全部实验：构造负载、flush cache、发压、采集指标、汇总落盘 |

关键实现点：

- 提交字段必须是原生接口的 **`input_ids`**；使用 OpenAI 兼容接口的 `prompt_token_ids` 会被服务端以
  400 拒绝。
- 流式响应为 SSE，每块形如 `data: {json}`，`meta_info` 中携带递增的 `cached_tokens`，取最后一块为准。
- TTFT 取首个 SSE 数据块到达的时刻，TPOT = `(e2e - ttft) / (completion_tokens - 1)`。

---

## 5. 结果目录与报告表格的对应关系

```
results/
└── target1/
    ├── shared_prefix/run-1/      -> 报告表 1「共享前缀组」整列
    │   ├── raw_result.json       -> 逐请求 TTFT/TPOT/E2E/cached_tokens（p50/p95 由它算出）
    │   └── summary.csv           -> 报告表 1 的汇总行
    └── dispersed_prefix/run-1/   -> 报告表 1「分散前缀组」整列
        ├── raw_result.json
        └── summary.csv
```

报告表 1 中每个数值都可以在上述文件里找到：`summary.csv` 给出该组的汇总值，
`raw_result.json` 保留全部 32 条逐请求原始记录，便于复算 p50 / p95。

---

## 6. 仓库结构

```
HW2-李庚容/
├── README.md
├── report.pdf                          # 两次任务的报告（含流程图）
├── AI 使用说明情况（第二次挑战）.pdf
├── src/
│   └── target1/run_exp.py
└── results/
    └── target1/
        ├── shared_prefix/run-1/
        └── dispersed_prefix/run-1/
```
